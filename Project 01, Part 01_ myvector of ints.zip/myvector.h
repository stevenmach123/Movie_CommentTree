/*myvector.h*/

// 
// <YOUR NAME>
// U. of Illinois, Chicago
// CS 251: Fall 2019
// 
// Project #01: myvector class that mimics std::vector, but with my own
// implemenation outlined as follows:
//
// ???
//

#pragma once

#include <iostream>  // print debugging
#include <cstdlib>   // malloc, free

using namespace std;

class myvector
{
private:
  int* A;
  int  Size;
  int  Capacity;

public:
  // default constructor:
  myvector()  
  {
     // TODO
  }

  // constructor with initial size:
  myvector(int initial_size)  
  {
     // TODO
  }

  // copy constructor for parameter passing:
  myvector(const myvector& other)
  {
    //
    // we have to make a copy of the "other" vector, so...
    //
    A = new int[other.Capacity];  // allocate our own array of same capacity
    Size = other.Size;            // this vector is same size and capacity
    Capacity = other.Capacity;

    // make a copy of the elements into this vector:
    for (int i = 0; i < Size; ++i)
      A[i] = other.A[i];
  }

  int size()
  {
    //
    // TODO
    //
    return 0;
  }

  int& at(int i)
  {
    //
    // TODO
    //
    return *A;  // this is WRONG, but compiles for now
  }

  void push_back(int value)
  {
     //
     // TODO
     //
  }

};
